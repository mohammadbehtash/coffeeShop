import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { provideHttpClient, withInterceptorsFromDi, withXsrfConfiguration } from '@angular/common/http';

bootstrapApplication(AppComponent, {providers:[provideHttpClient(withInterceptorsFromDi()
  // ,withXsrfConfiguration({ cookieName: 'XSRF-TOKEN', headerName: 'X-CSRF-TOKEN' })
),
  
]})
  .catch((err) => console.error(err));
