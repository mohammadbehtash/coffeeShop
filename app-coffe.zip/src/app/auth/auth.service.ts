import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CsrfService } from '../csrf/csrf.service';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private BaseUrl = 'http://localhost:4000/auth'
  headers!: HttpHeaders;
  constructor(private http: HttpClient, private csrfService: CsrfService) { }
  // send Code
  // async postData(data: any) {
  //   const csrfToken = await this.csrfService.getCsrfToken();

  //   this.headers = new HttpHeaders()
  //     .set('X-CSRF-TOKEN', csrfToken || '')
  //     .set('Content-Type', 'application/json');
  // }


   sendEmail(email: string) {
    //  this.postData(null); 
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.post<string>(this.BaseUrl + '/send-verification-code', { email }, {
      // headers: { "Content-Type": "application/json" }
      headers,withCredentials: true
    });
  }


  verifiEmail(verificationCode:string){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.post<string>(this.BaseUrl + '/verify-code-and-register', { verificationCode }, {headers,withCredentials: true});
  }


  register(register:any){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.post<string>(this.BaseUrl+'register',{register},{headers,withCredentials:true})
  }


  loginuser(loginForm:any){
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.post<any>(this.BaseUrl+'/login',loginForm,{
      headers,withCredentials: true
    })
  }


   refreshToken() {
    return this.http.get<{ accessToken: string }>(this.BaseUrl + '/refresh-token', { withCredentials: true });
  }
}
