import { Component, OnDestroy, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { AllService } from './service/all.service';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from "./auth/login/login.component";
import { SharedModule } from './shared/shared.module';
import { AuthFormComponent } from "./auth/auth-form/auth-form.component";
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, CommonModule, HomeComponent, FooterComponent, LoginComponent, SharedModule, AuthFormComponent,RouterModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit,OnDestroy {
  private subscription: Subscription | undefined;
  navOpen: boolean = false;
  constructor(private allservice:AllService){}

ngOnInit(): void {
  this.subscription=this.allservice.openNav$.subscribe(status=>{
    this.navOpen=status
  })
}
ngOnDestroy(): void {
  this.subscription?.unsubscribe()
}

}
