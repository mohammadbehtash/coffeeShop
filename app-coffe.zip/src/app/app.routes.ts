import { Routes } from '@angular/router';
import { AuthFormComponent } from './auth/auth-form/auth-form.component';
import { SendCodeComponent } from './auth/send-code/send-code.component';
import { VerifyEmailComponent } from './auth/verify-email/verify-email.component';
import { RegisterComponent } from './auth/register/register.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'auth',component:AuthFormComponent,children:[
        {path:'',component:SendCodeComponent},
        {path:'verifi-email',component:VerifyEmailComponent},
        {path:'register',component:RegisterComponent},
    ]}
];
