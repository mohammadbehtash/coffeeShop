import { Component } from '@angular/core';
import { DirectionComponent } from "../direction/direction.component";

@Component({
  selector: 'app-all-products',
  standalone: true,
  imports: [DirectionComponent],
  templateUrl: './all-products.component.html',
  styleUrl: './all-products.component.css'
})
export class AllProductsComponent {

}
