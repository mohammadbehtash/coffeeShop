import { AfterViewInit, Component, ElementRef, inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, Subscription } from 'rxjs';

import { AllService } from '../service/all.service';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit, OnDestroy {
  navOpen: boolean = false;
  CartOpen: boolean = false;
  submenu: boolean = false
  
  private subscriprion: Subscription | undefined
  private subscriprion2: Subscription | undefined

  constructor(public appservice: AllService) { }


  toggelNav(status: boolean) {
    this.appservice.setOpenNav(status)
  }
  toggelCart(status: boolean) {
    this.appservice.setOpenCart(status)
  }


toggleDarkMode(){
  const isDark=localStorage.getItem('dark')?false:true
  this.appservice.setDarkMode(isDark)
}
  ngOnInit() {
    this.appservice.checkDarkMode();
    
    // submenu
    this.subscriprion = this.appservice.openNav$.subscribe(status => {
      this.navOpen = status
    })
    // cart
    this.subscriprion2 = this.appservice.openCart$.subscribe(status => {
      this.CartOpen = status
    })
  }
  ngOnDestroy(): void {
    this.subscriprion?.unsubscribe()
    this.subscriprion2?.unsubscribe()
  }
  // team
  

}
