import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ProductBoxComponent } from '../product-box/product-box.component';
import { AllService } from '../service/all.service';
import Swiper from 'swiper';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ProductBoxComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit,AfterViewInit {
img:string='assets/categories/category1.png'
constructor(private allservice:AllService){}

ngAfterViewInit(): void {
  new Swiper('.swiper', {
    slidesPerView: 2,
    spaceBetween: 14,
    loop: true,
    navigation: {
      nextEl: '#swiper-button-next-custom',
      prevEl: '#swiper-button-prev-custom'
    },
    breakpoints: {
      640: {
        slidesPerView: 3,
        spaceBetween: 14
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      1024: {
        slidesPerView: 4,
        spaceBetween: 20
      }
    }
  });
}



ngOnInit(): void {
  
}
}
